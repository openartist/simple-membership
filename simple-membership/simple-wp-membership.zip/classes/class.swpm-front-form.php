<?php

class SwpmFrontForm extends SwpmForm{
	public function membership_level(){
		
	}
}