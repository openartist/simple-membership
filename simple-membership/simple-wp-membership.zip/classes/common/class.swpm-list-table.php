<?php

/*
 * Base class for handling list tables.
 */

/*** This class is currently not being used ***/
