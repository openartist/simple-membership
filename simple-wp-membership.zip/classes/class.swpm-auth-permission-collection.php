<?php
/**
 * Description of BAuthPermissionCollection
 *
 * @author nur
 */
class SwpmAuthPermissionCollection extends SwpmPermissionCollection{
//put your code here
}
