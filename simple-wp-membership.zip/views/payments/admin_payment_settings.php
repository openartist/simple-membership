<?php
//TODO - this menu tab can be removed in the future. It is here for backward compatibility.

?>
<div class="swpm-yellow-box">
    <p>
    <?php _e('The payment settings have moved to the <b>Payment Settings</b> tab in the <strong>Payments</strong> menu. Click the link below to navigate to the new location.','simple-membership');?>
    </p>
    <p>
    <a class="button-primary" href="admin.php?page=simple_wp_membership_payments&tab=payment_settings"><?php _e('Go to the new Payment Settings location','simple-membership');?></a>
    </p>
</div>
<?php
